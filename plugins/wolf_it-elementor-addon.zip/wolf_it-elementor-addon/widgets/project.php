<?php
class project_widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'project_widget';
	}

	public function get_title()
	{
		return esc_html__('Project', 'wolf_it');
	}

	public function get_icon()
	{
		return 'eicon-flash';
	}

	public function get_categories()
	{
		return ['wolf_it-elementor-addon'];
	}

	public function get_keywords()
	{
		return ['project', 'projects'];
	}

	protected function register_controls()
	{
    // Content Section

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__('Content', 'elementor-currency-control'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'project_per_page',
        [
            'label' => esc_html__( 'Project Per Row', 'wolf_it' ),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 100,
            'step' => 1,
            'default' => 4,
        ]
    );

    $this->end_controls_section();


    }


	protected function render(){
    $settings = $this->get_settings_for_display();
    $project_per_page = $settings['project_per_page'];

   ?>
        <section class="projects_page ">
        <div class="project">
            <div class="row">
                <?php
        // The Query
        $args = array(
            'post_type' => 'project',
            'posts_per_page' => $project_per_page,
        );

        $query = new WP_Query($args);

        // The Loop
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                ?>
                <div class="col-xl-3 col-sm-6 col-lg-4 wow fadeInUp" data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: fadeInUp;">
                <div class="project_item">
                        <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid w-100">
                        <div class="project_item_text">
                            <!-- <span>web design</span> -->
                            <h3><?php the_title(); ?></h3>
                            <a href="<?php the_permalink(); ?>">Read More <i class="fal fa-long-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            <?php
            }
        } else {
            // No posts found
            echo 'No posts found';
        }

        // Restore original Post Data
        wp_reset_postdata();
       ?>
            </div>
        </div>
    </section>
       <?php
}
}
