<?php
class team_widget extends \Elementor\Widget_Base
{

	public function get_name()
	{
		return 'team_widget';
	}

	public function get_title()
	{
		return esc_html__('Team', 'wolf_it');
	}

	public function get_icon()
	{
		return 'eicon-user-circle-o';
	}

	public function get_categories()
	{
		return ['wolf_it-elementor-addon'];
	}

	public function get_keywords()
	{
		return ['Team', 'Teams'];
	}

	protected function register_controls()
	{
    // Content Section

    $this->start_controls_section(
        'content_section',
        [
            'label' => esc_html__('Content', 'elementor-currency-control'),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'team_per_page',
        [
            'label' => esc_html__( 'Team Per Row', 'wolf_it' ),
            'type' => \Elementor\Controls_Manager::NUMBER,
            'min' => 1,
            'max' => 100,
            'step' => 1,
            'default' => 4,
        ]
    );

    $this->end_controls_section();


    }


	protected function render(){
    $settings = $this->get_settings_for_display();
    $team_per_page = $settings['team_per_page'];

   ?>
        <section class="team_page">
        <div class="team">
            <div class="row">
                <?php
        // The Query
        if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
        elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
        else { $paged = 1; } 
        $args = array(
            'post_type' => 'teams',
            'posts_per_page' => $team_per_page,
            'paged'     => $paged,
        );

        $query = new WP_Query($args);

        // The Loop
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                ?>
                <div class="col-xl-3 col-sm-6 col-lg-4 wow fadeInUp" data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: fadeInUp;">
                    <div class="single_team">
                        <img src="<?php the_post_thumbnail_url(); ?>" alt="" class="img-fluid w-100">
                        <div class="text">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            <p><?php the_field('team_subtitle') ?></p>
                        </div>
                        <ul>
                        <?php 
                            $team_social = get_field('team_social');
                            if ($team_social){
                                foreach ($team_social as $social){
                                    ?>    
                                    <li>
                                    <a href="<?php echo $social ['team_social_url']; ?>" target="_blank"><i class="<?php echo $social ['team_social_icon']; ?>" aria-hidden="true"></i></a>
                                    </li>
                                    <?php
                                }}
                            ?>
                        </ul>
                    </div>
                </div>
            <?php
            }
        } else {
            // No posts found
            echo 'No posts found';
        }

        // Restore original Post Data
        wp_reset_postdata();
       ?>
        <div class="pagination_area mt_60">
        <div class="row">
            <div class="col-12">
                <nav>
                    <ul class="pagination">
                        <?php  echo paginate_links(array(
                             'total' => $query->max_num_pages,
                             'current'      => max( 1, $paged ), // For Active Current Class
                            'prev_text' => __( '<i class="fas fa-chevron-double-left"></i>', 'wolf_it' ),
                            'next_text' => __( '<i class="fas fa-chevron-double-right"></i>', 'wolf_it' ),
                        ) ); ?>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
            </div>
        </div>
    </section>
       <?php
}
}
